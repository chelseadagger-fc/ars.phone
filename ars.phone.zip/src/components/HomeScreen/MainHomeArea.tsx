export default function MainHomeArea() {
    
  return(
        <div className="h-5/6 bg-neutral-400">
          <p className="text-3xl text-black-700">MAIN HOME AREA</p>
        </div>
  )
}