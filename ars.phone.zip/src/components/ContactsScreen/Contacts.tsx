export default function Contacts() {
    
    return(
        <div className="h-dvh">
            <p>CONTACTS</p>
        </div>
    )
}